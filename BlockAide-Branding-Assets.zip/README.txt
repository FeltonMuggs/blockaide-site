BlockAide Union — Branding Asset Pack (v1, 2026-07-21)

provenance-qr.png        QR -> https://blockaide.org/provenance (web, 468px)
provenance-qr-print.png  QR -> https://blockaide.org/provenance (print, 1560px; ~5in at 300dpi)
provenance-qr.svg        QR vector (scale to any size; recolor fill to #1d333a on white)
blockaide-palette.png    Brand palette reference card
logo.png / logo.jpg      BlockAide Union shield logo
Note: keep QR codes dark-on-light with a clear quiet zone; verified scannable 2026-07-21.
